#ifndef GAMEOFLIFE_H
#define GAMEOFLIFE_H

#include <vector>
#include <SDL.h>

class GameOfLife {
public:
    GameOfLife(int width, int height, int cellSize);
    ~GameOfLife();

    void initRandom();
    void update();
    void render(SDL_Renderer* renderer);
    void toggleCell(int mouseX, int mouseY);
    void reset();

    bool isRunning() const { return running; }
    void setRunning(bool state) { running = state; }

private:
    int width;
    int height;
    int cellSize;
    int rows;
    int cols;
    std::vector<std::vector<bool>> grid;
    std::vector<std::vector<bool>> nextGrid;
    bool running;

    int countLiveNeighbors(int r, int c);
};

#endif // GAMEOFLIFE_H
